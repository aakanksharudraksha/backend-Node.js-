const Message = require('../models/message');

exports.getMessages = async (req, res) => {
  try {
    const messages = await Message.find({ group: req.params.groupId })
      .populate('sender', 'username')
      .sort('timestamp');
    res.status(200).json({ success: true, data: messages });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};
