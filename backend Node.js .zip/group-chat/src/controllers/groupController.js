const Group = require('../models/group');
const User = require('../models/user');

exports.createGroup = async (req, res) => {
  try {
    const { name } = req.body;
    const group = await Group.create({ name, members: [req.user.id] });
    res.status(201).json({ success: true, data: group });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};

exports.joinGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group.members.includes(req.user.id)) {
      group.members.push(req.user.id);
      await group.save();
    }
    res.status(200).json({ success: true, data: group });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};

exports.leaveGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    group.members.pull(req.user.id);
    await group.save();
    res.status(200).json({ success: true, data: group });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};
