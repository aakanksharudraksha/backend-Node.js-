const Message = require('../models/message');
const Group = require('../models/group');

module.exports = (io) => {
  io.on('connection', (socket) => {
    console.log('New client connected');

    socket.on('joinGroup', async ({ groupId, userId }) => {
      socket.join(groupId);
      const group = await Group.findById(groupId);
      group.members.push(userId);
      await group.save();
      io.to(groupId).emit('updateGroup', group);
    });

    socket.on('leaveGroup', async ({ groupId, userId }) => {
      socket.leave(groupId);
      const group = await Group.findById(groupId);
      group.members.pull(userId);
      await group.save();
      io.to(groupId).emit('updateGroup', group);
    });

    socket.on('sendMessage', async ({ groupId, userId, content }) => {
      const message = await Message.create({ group: groupId, sender: userId, content });
      io.to(groupId).emit('newMessage', message);
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected');
    });
  });
};
