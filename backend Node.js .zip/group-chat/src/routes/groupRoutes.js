const express = require('express');
const { createGroup, joinGroup, leaveGroup } = require('../controllers/groupController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/create', protect, createGroup);
router.put('/:groupId/join', protect, joinGroup);
router.put('/:groupId/leave', protect, leaveGroup);

module.exports = router;
